from flask.ext.wtf import Form
from wtforms import StringField, PasswordField, SubmitField, TextAreaField, RadioField, SelectField,IntegerField,\
    FileField,HiddenField,validators, DateField
from wtforms.validators import DataRequired, Length, EqualTo, Regexp, Email
import dbquery

class LoginForm(Form):

    username = StringField('Username',[validators.Length(min=4, max=25)])
    password = PasswordField("Password")
    signin = SubmitField('Sign In')

class RegisterForm(Form):

    username = StringField("Username",[validators.Length(min=4, max=25),  validators.Regexp('^\w+$', message="Username must contain only letters, numbers or underscore")])
    email = StringField("Email",[validators.Length(min=4, max=25), validators.Email()])
    password = PasswordField("Password",[
        validators.DataRequired(),
        validators.EqualTo('confirm', message='Passwords must match'), Regexp('^\w+$', message="Password must contain only letters, numbers or underscore")
    ])
    confirm = PasswordField("Repeat password")
    register = SubmitField("Register")


class TutorRegistration(Form):

    username = StringField("Username", validators=[DataRequired(), Regexp('^\w+$', message="Username must contain only letters, numbers or underscore")])
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired(), EqualTo('confirm', message='Passwords must match'), Regexp('^\w+$', message="Password must contain only letters, numbers or underscore")])
    confirm = PasswordField("Repeat password")
    name = StringField("Name", validators=[DataRequired(), Regexp('^\w+|\s$', message="Name must contain only letters, numbers or underscore")])
    surname = StringField("Surname", validators=[DataRequired(), Regexp('^\w+|\s$', message="Surname must contain only letters, numbers or underscore")])
    date = DateField('Date of birth (in the form: year-month-day)', format='%Y-%m-%d', validators=[DataRequired()])
    city = StringField('City of your Erasmus experience', validators=[DataRequired(), Regexp('^\w+|\s$', message="City must contain only letters, numbers or underscore")])
    university = StringField('University of your Erasmus experience', validators=[DataRequired(), Regexp('^\w+|\s$', message="University must contain only letters, numbers or underscore")])
    description= TextAreaField('Give a description of your experience', [validators.Regexp('^\w+|\s$', message="Description must contain only letters, numbers or underscore")])
    submit = SubmitField('Register')


class TutorRegistrationFromStudent(Form):

    username = HiddenField()
    name = StringField("Name", validators=[DataRequired(), Regexp('^\w+|\s$', message="Name must contain only letters, numbers or underscore")])
    surname = StringField("Surname", validators=[DataRequired(), Regexp('^\w+|\s$', message="Surname must contain only letters, numbers or underscore")])
    date = DateField('Date of birth (in the form: year-month-day)', format='%Y-%m-%d', validators=[DataRequired()])
    city = StringField('City of your Erasmus experience', validators=[DataRequired(), Regexp('^\w+|\s$', message="City must contain only letters, numbers or underscore")])
    university = StringField('University of your Erasmus experience', validators=[DataRequired(), Regexp('^\w+|\s$', message="University must contain only letters, numbers or underscore")])
    description= TextAreaField('Give a description of your experience', [validators.Regexp('^\w+|\s$', message="Description must contain only letters, numbers or underscore")])
    submit = SubmitField('Register')


class ForumForm(Form):

    cities_opt=[]
    for city in dbquery.get_all_cities():
        cities_opt.append((city,city))

    cities = SelectField('Choose your city:', choices=cities_opt)
    submit = SubmitField('Search')


class UploadForm(Form):

    university = HiddenField()
    title = StringField(validators=[DataRequired(), Regexp('^\w+|\s$', message="Title must contain only letters, numbers or underscore")])
    professor = StringField(validators=[DataRequired(), Regexp('^\w+|\s$', message="Professor must contain only letters, numbers or underscore")])
    subject = StringField(validators=[DataRequired(), Regexp('^\w+|\s$', message="Subject must contain only letters, numbers or underscore")])
    description = TextAreaField(validators=[DataRequired(), Regexp('^\w+|\s$', message="Description must contain only letters, numbers or underscore")])
    doc = FileField(u'Document File')
    submit = SubmitField()


class MaterialForm(Form):

    university = HiddenField()

    universities_opt=[]
    for uni in dbquery.get_all_universities():
         universities_opt.append((uni,uni))

    universities = SelectField('Choose your university:', choices=universities_opt)
    submit = SubmitField('Search')


class RatingForm(Form):

    material = HiddenField()
    rate = SubmitField('Rating')


class DownloadForm(Form):

        link = HiddenField()
        download = SubmitField('Download')

class DeleteForm(Form):
    material = HiddenField()
    delete = SubmitField('Delete')


class TopicForm(Form):
     topic = HiddenField()
     flag = HiddenField()
     flag = False
     submit = SubmitField('Look at the discussion')


class AddTopicForm(Form):
    topic_id=  HiddenField()
    city = HiddenField()
    title = StringField('Insert the new topic name: ', validators=[DataRequired(), Length(min=4, max=80), Regexp('^\w+|\s$', message="Title must contain only letters, numbers or underscore")])
    topic_question = StringField('Insert a new question:', validators=[DataRequired(), Length(min=4, max=100), Regexp('^\w+|\s$', message="Question must contain only letters, numbers or underscore")])
    submit = SubmitField('Submit')


class AddQuestionForm(Form):
    city=HiddenField()
    topic_id=HiddenField()
    question = StringField('Insert a new question or answer: ', validators=[DataRequired(), Length(min=4, max=100), Regexp('^\w+|\s$', message="Question must contain only letters, numbers or underscore")])
    submit = SubmitField('Submit')


class ContactForm(Form):
  name = StringField("Name",  [validators.DataRequired("Please enter your name."), Regexp('^\w+|\s$', message="Name must contain only letters, numbers or underscore")])
  email = StringField("Email",  [validators.DataRequired("Please enter your email address."), validators.Email("Please enter your email address.")])
  subject = StringField("Subject",  [validators.DataRequired(), Regexp('^\w+|\s$', message="Subject must contain only letters, numbers or underscore")])
  message = TextAreaField("Message",  [validators.DataRequired("Please enter a message."), Regexp('^\w+|\s$', message="Message must contain only letters, numbers or underscore")])
  submit = SubmitField("Send")


class PhotoForm(Form):

    username = HiddenField()
    tutor = HiddenField()
    photo = FileField("Your photo")
    submit = SubmitField()

class SearchForm(Form):

    word = StringField("", validators=[DataRequired(), Length(min=4, max=80), Regexp('^\w+|\s$', message="Search field must contain only letters, numbers or underscore")])
    submit = SubmitField("Search")