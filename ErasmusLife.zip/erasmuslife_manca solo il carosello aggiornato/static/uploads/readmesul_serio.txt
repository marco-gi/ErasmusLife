Per visualizzare sul browswr il sito con parte dinamica implementate in pyton digitare nella riga negli indirizzi:
127.0.0.1:5000
