$(document).ready(function($){
  $('#login').click(function(){
    $('#modal1').modal('show');
  });

  $('#registrazioneBtn').click(function(){
  	$('#modal2').modal('show');
  });

  $('#registrazione').click(function(){
  	$('#modal2').modal('show');
  });

  $('#registrazioneTutor').click(function(){
  	$('#modal2').modal('hide');
    $('#modal3').modal('show');
  });

  $('#signUp').click(function(){
    var username=$('#exampleInputUsername').val();
    var pw=$('#exampleInputPassword').val();
    var email=$('#exampleInputEmail1').val();
    var reg = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    if(reg.test(email) && pw!=' ' && username!=' '){
      console.log('1');
    }else{
      console.log('0');
      window.alert('Dati inseriti mancanti o non corretti');
    }
  });

  $('#signUpTutor').click(function(){
    var username=$('#exampleInputUsername2').val();
    var pw=$('#exampleInputPassword2').val();
    var email=$('#exampleInputEmail2').val();
    var name=$('#exampleInputName').val();
    var surname=$('#exampleInputSurname').val();
    var age=$('#exampleInputAge').val();
    var bCity=$('#exampleInputBirthCity').val();
    var uni=$('#exampleInputUniversity').val();
    var tCity=$('#exampleInputTutoringCity').val();

    var regE = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    var regN = /^[a-zA-Z]+$/;
    var regA = /^(0?[1-9]|[1-9][0-9])$/;

    if(username!=' ' && pw!=' ' && regE.test(email) && regN.test(name) && regN.test(surname) && regA.test(age) && regN.test(bCity) && regN.test(uni) && regN.test(tCity)){
      console.log('1');
    }else{
      console.log('0');
      window.alert('Dati inseriti mancanti o non corretti');
    }
  });
  $('#signIn').click(function(){
    var username=$('#exampleInputUsername1').val();
    var pw=$('#exampleInputPassword1').val();
    if (username!='' && pw!='') {
      console.log('1');
    }else{
      console.log('0');
      window.alert('Dati inseriti mancanti o non corretti');
    }
  });
});
