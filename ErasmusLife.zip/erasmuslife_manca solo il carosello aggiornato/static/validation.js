/**
 * Created by Marco on 01/12/2015.
 */
// jQuery(document).ready(function($) {
//
//     $("#logForm1").validate();
//
//
// })
