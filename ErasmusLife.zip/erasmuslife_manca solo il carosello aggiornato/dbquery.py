import os
from dbdatabase import Base, User, University, Material,Topic,Question,DateTime, Tutor
from sqlalchemy import create_engine, or_, func
from sqlalchemy.orm import sessionmaker, scoped_session

from datetime import datetime

engine = create_engine('mysql://root@localhost/erasmuslife')
Session = scoped_session(sessionmaker(bind=engine))

Base.metadata.create_all(engine)
Base.query = Session.query_property()

session = Session()

session.commit()


def get_all_cities():
    university_cities = University.query.group_by(University.city)
    cities=[]
    for uni in university_cities:
        cities.append(uni.city)
    return cities


def get_all_universities():
    university_names = University.query.group_by(University.name)
    universities=[]
    for uni in university_names:
        universities.append(uni.name)
    return universities


def get_all_materials():
    materials = Material.query.all()
    return materials


def get_materials(uni):
    materials = session.query(Material).filter_by(university=uni).all()
    session.close()
    return materials


def find_username(username):
    num= session.query(User).filter_by(username=username).count()
    session.close()
    return num


def find_username_tutor(username):
    num= session.query(Tutor).filter_by(username=username).count()
    session.close()
    return num


def get_user(username):
    name= session.query(User).filter_by(username=username).first()
    session.close()
    return name


def get_topics_from_city(city):
    topics_by_cities = session.query(Topic).filter_by(city=city)
    session.close()
    return topics_by_cities


def get_question_from_topic(topic):
    questions_by_topic = session.query(Question).filter_by(id_topic=topic)
    session.close()
    return questions_by_topic


def countTopic():
    last_id = int(session.query(Topic).order_by('-id').first().id)
    t_id = last_id+1
    return t_id


def countQuestion():
    number = int(session.query(Question).order_by('-id').first().id)
    return number+1


def countMaterial():
    last = int(session.query(Material).order_by('-id').first().id)
    return last+1


def newTopic(username, city, topic):
    id = countTopic()
    date = datetime.now()
    topic = Topic(id, topic, username, date, city)
    return topic


def newQuestion(username, question, topic):
    id = countQuestion()
    date = datetime.now()
    question = Question(id, topic, username, question, date)
    return question


def find_tutor(username):
    tutor= session.query(Tutor).filter_by(username=username).first()
    session.close()
    return tutor


def find_all_tutor():
    tutors= session.query(Tutor).all()
    session.close()
    return tutors


def find_material_from_author(author):
    materials=session.query(Material).filter_by(author=author)
    session.close()
    return materials


def get_material_by_id(id_material):
    material = session.query(Material).filter_by(id = id_material)
    session.close()
    return material


def get_rating_by_id(id):
    rate = session.query(Material).filter_by(id = id).first()
    session.close()
    return rate.rating


def get_city(city):
    num_city = session.query(University).filter_by(city=city).count()
    session.close()
    return num_city


def get_uni(university):
    num_uni = session.query(University).filter_by(name=university).count()
    session.close()
    return num_uni


def get_res_material(word):
    words=word.split(' ')
    results=set()
    for w in words:
        for i in session.query(Material).filter(Material.title.ilike('%'+w+'%')).all():
            results.add(i)
    for w in words:
        for i in session.query(Material).filter(Material.professor.ilike('%'+w+'%')).all():
            results.add(i)
    for w in words:
        for i in session.query(Material).filter(Material.subject.ilike('%'+w+'%')).all():
            results.add(i)
    for w in words:
        for i in session.query(Material).filter(Material.description.ilike('%'+w+'%')).all():
            results.add(i)
    session.close()
    return results

def get_res_university(word):
    words=word.split(' ')
    results=set()
    for w in words:
        for i in session.query(University).filter(University.name.ilike('%'+w+'%')).all():
            results.add(i)
    for w in words:
        for i in session.query(University).filter(University.city.ilike('%'+w+'%')).all():
            results.add(i)
    session.close()
    return results

def get_res_quest(word):
    words=word.split(' ')
    results=set()
    for w in words:
        for i in session.query(Question).filter(Question.question.ilike('%'+w+'%')).all():
            results.add(i)
    session.close()
    return results

def get_res_topic(word):
    words = word.split(' ')
    results = set()
    for w in words:
        for i in session.query(Topic).filter(Topic.topic.ilike('%'+w+'%')).all():
            results.add(i)
    for w in words:
        for i in session.query(Topic).filter(Topic.city.ilike('%'+w+'%')).all():
            results.add(i)
    session.close()
    return results

def get_res_tutor(word):
    words=word.split(' ')
    results=set()
    for w in words:
        for i in session.query(Tutor).filter(Tutor.username.ilike('%'+w+'%')).all():
            results.add(i)
    for w in words:
        for i in session.query(Tutor).filter(Tutor.name.ilike('%'+w+'%')).all():
            results.add(i)
    for w in words:
        for i in session.query(Tutor).filter(Tutor.description.ilike('%'+w+'%')).all():
            results.add(i)
    for w in words:
        for i in session.query(Tutor).filter(Tutor.university.ilike('%'+w+'%')).all():
            results.add(i)
    for w in words:
        for i in session.query(Tutor).filter(Tutor.city.ilike('%'+w+'%')).all():
            results.add(i)
    session.close()
    return results

def get_all_topics():
    topics= session.query(Topic).all()
    session.close()
    return topics

def get_city_byuni(university):
    c = session.query(University).filter_by(name=university).first()
    session.close()
    return c.city

def get_uni_bycity(city, university):
    c = session.query(University).filter(University.name == university, University.city == city).count()
    session.close()
    return c
