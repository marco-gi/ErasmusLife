import os
from flask import Flask, render_template, redirect, url_for, request, send_from_directory,current_app,flash,abort,session,escape, Markup
from sqlalchemy.util.compat import b64encode
from dbdatabase import db, Base, User, Material,Question,Tutor,University
from flask.ext.bootstrap import Bootstrap
from form import ForumForm, MaterialForm, TopicForm,UploadForm,DownloadForm,DeleteForm,RatingForm,AddTopicForm, AddQuestionForm,LoginForm,RegisterForm,TutorRegistration, \
    ContactForm, PhotoForm, SearchForm, TutorRegistrationFromStudent
from werkzeug.utils import secure_filename
from flask_login import LoginManager,login_user,current_user, logout_user, login_required
from datetime import datetime
import dbquery
from flask.ext.mail import Mail, Message
from validate_email import validate_email

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] ='mysql://root@localhost/erasmuslife'
db.init_app(app)
bootstrap = Bootstrap(app)
login_manager = LoginManager(app)
login_manager.session_protection = 'strong'
login_manager.login_view = 'login'
login_manager.init_app(app)
# set the secret key.  keep this really secret:
app.secret_key = 'ciaociao'

mail = Mail()

app.config["MAIL_SERVER"] = "smtp.gmail.com"
app.config["MAIL_PORT"] = 465
app.config["MAIL_USE_SSL"] = True
app.config["MAIL_USERNAME"] = 'erasmuslife.contact@gmail.com'
app.config["MAIL_PASSWORD"] = 'gestionale'

mail.init_app(app)


@login_manager.user_loader
def load_user(username):
    return dbquery.get_user(username)

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(APP_ROOT, 'static/uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


app.config['ALLOWED_EXTENSIONS'] = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'])


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1] in app.config['ALLOWED_EXTENSIONS']


@app.before_first_request
def init_db():
    db.create_all()


@app.route('/')
def index():
    formSearch=SearchForm()
    return render_template('homepage.html', formSearch=formSearch)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = load_user(form.username.data)
        if user is not None and user.verify_password(form.password.data):
            login_user(user)
            flash(('success', 'Login successful!'))
            return redirect(request.args.get('next', url_for('index')))
        else:
            flash(('danger', 'Wrong username and/or password.'))
    return render_template('login.html', form=form)


@app.route('/logout')
def logout():
    logout_user()
    flash(('success', 'Logged out!'))
    return redirect(request.args.get('next', url_for('index')))


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    form = RegisterForm()
    if form.validate_on_submit():
        if dbquery.find_username(form.username.data)== 0:
            username = request.form['username']
            email = request.form['email']
            password = request.form['password']

            if validate_email(email):
                user = User(username, 'S', password, email)
                db.session.add(user)
                db.session.commit()

                login_user(user)

                flash(('success', 'Registration successful!'))
                return redirect(url_for('index'))
            else:
                flash(('warning', 'The email is not valid.'))
        else:
            flash(('warning', 'Username already exists.'))

    return render_template('signup.html', form = form)


@app.route('/tutorsignup', methods=['GET', 'POST'])
def tutorsignup():
    form = TutorRegistration()
    if form.validate_on_submit():
        if dbquery.find_username_tutor(form.username.data) == 0:
            username = request.form['username']
            email = request.form['email']
            password = request.form['password']
            name = request.form['name']
            surname= request.form['surname']
            date = request.form['date']
            city = request.form['city']
            university = request.form['university']
            description = request.form['description']

            cities=dbquery.get_all_cities()
            flag=False
            citydb=''
            unidb=''
            for c in cities:
                if c.upper()==city.upper():
                    citydb=c
                    flag=True
            if flag==False:
                flash(('warning', 'The city does not exist yet.'))
            universities=dbquery.get_all_universities()
            flag1=False
            for c in universities:
                if c.upper()==university.upper():
                    unidb=c
                    flag1=True
            if flag1==False:
                flash(('warning', 'The university does not exist yet.'))
            elif dbquery.get_city_byuni(unidb)!=citydb:
                flash(('warning', 'The university has to be in the right city.'))
            elif dbquery.get_uni_bycity(citydb, unidb)==0:
                flash(('warning', 'The university has to be in the right city.'))
            elif not validate_email(email):
                flash(('warning', 'The email is not valid.'))
            else:
                user = User(username,'T',password,email)
                db.session.add(user)
                db.session.commit()

                login_user(user)

                tutor = Tutor(username,name,surname,date,description,citydb,unidb,'') #mettiamo anche foto??
                db.session.add(tutor)
                db.session.commit()

                flash('Thanks for registering')
                return redirect(url_for('personalpage', username=username))
        else:
            flash(('warning', 'Username already exists.'))
    return render_template('tutorsignup.html',form = form)

@app.route('/tutorsignupfromstud', methods=['GET', 'POST'])
def tutorsignupfromstud():
    form = TutorRegistrationFromStudent()
    if form.validate_on_submit():
            username=request.form['username']
            userstud=dbquery.get_user(username)
            email = userstud.email
            password = userstud.password_hash
            name = request.form['name']
            surname= request.form['surname']
            date = request.form['date']
            city = request.form['city']
            university = request.form['university']
            description = request.form['description']

            cities=dbquery.get_all_cities()
            flag=False
            citydb=''
            unidb=''
            for c in cities:
                if c.upper()==city.upper():
                    citydb=c
                    flag=True
            if flag==False:
                flash(('warning', 'The city does not exist yet.'))
            universities=dbquery.get_all_universities()
            flag1=False
            for c in universities:
                if c.upper()==university.upper():
                    unidb=c
                    flag1=True
            if flag1==False:
                flash(('warning', 'The university does not exist yet.'))
            elif dbquery.get_city_byuni(unidb)!=citydb:
                flash(('warning', 'The university has to be in the right city.'))
            elif dbquery.get_uni_bycity(citydb, unidb)==0:
                flash(('warning', 'The university has to be in the right city.'))
            elif not validate_email(email):
                flash(('warning', 'The email is not valid.'))
            else:
                db.session.query(User).filter(User.username == username).update({'types': 'T'})
                db.session.commit()

                user=dbquery.get_user(username)

                login_user(user)

                tutor = Tutor(username,name,surname,date,description,citydb,unidb,'')
                db.session.add(tutor)
                db.session.commit()

                flash('Thanks for registering')
                return redirect(url_for('personalpage', username=username))
    else:
            flash(('warning', 'Username already exists.'))
    return render_template('tutorsignupfromstudent.html', form=form)

@app.route('/results', methods=['GET', 'POST'])
def search():
    formSearch=SearchForm()
    results_mat=set()
    results_tutor=set()
    results_topic=set()
    results_quest=set()
    results_all_top=[]
    if formSearch.validate_on_submit():
        results_mat=dbquery.get_res_material(request.form['word'])
        results_quest=dbquery.get_res_quest(request.form['word'])
        results_tutor=dbquery.get_res_tutor(request.form['word'])
        results_topic=dbquery.get_res_topic(request.form['word'])
        results_all_top=dbquery.get_all_topics()
    return render_template("results.html", results_mat=results_mat, results_tutor=results_tutor, results_quest=results_quest, results_topic=results_topic, topics=results_all_top)



@app.route('/personalpage/<username>')
@login_required
def personalpage(username):
    formRate = RatingForm()
    formDown = DownloadForm()
    formDel = DeleteForm()
    formPhoto = PhotoForm()
    tutor = dbquery.find_tutor(username)
    materials = dbquery.find_material_from_author(username)

    if formPhoto.validate_on_submit():
        file = request.files['photo']
        username = request.form['username']
        db.session.query(Tutor).filter(Tutor.username == username).update(
        {'photo': file})  # method to update column database
        db.session.commit()
        return redirect(url_for('personalpage', username=username))
    return render_template('personalpage.html', tutor=tutor, materials=materials, formRating=formRate,
                               formDownload=formDown, formDelete=formDel, formPhoto=formPhoto)


@app.route('/tutorpage')
@login_required
def tutorpage():
    tutors = dbquery.find_all_tutor()
    return render_template('tutorpage.html', tutors=tutors)


@app.route('/material', methods=['GET', 'POST'])
def material():
    form = MaterialForm()
    if form.validate_on_submit():
        university = request.form['universities']
        return redirect(url_for('materialsearch', university=university))

    return render_template('material.html', form=form)

@app.route('/materialsearch/<university>', methods=['GET', 'POST'])
def materialsearch(university):
    form = MaterialForm()
    form2 = UploadForm()
    formRate = RatingForm()
    formDown = DownloadForm()
    formDel = DeleteForm()
    materials=[]
    materials_db = dbquery.get_materials(university)
    city = dbquery.get_city_byuni(university)
    for m in materials_db:
        materials.append(m)
    return render_template('materialsearch.html',materials=materials, formRating=formRate,
                               formDownload=formDown, formDelete=formDel, form2=form2, university=university, city=city, form=form)

@app.route('/topic/<city>', methods=['GET', 'POST'])
@login_required
def topic(city):
    form = TopicForm()
    form_newTopic = AddTopicForm()
    if form.validate_on_submit():
        topic_id = request.form['topics']
        return render_template('question.html', city=city, topic_id=topic_id)

    to_id = dbquery.countTopic()
    topics = dbquery.get_topics_from_city(city)
    return render_template('topic.html', form=form, topics=topics, form_newTopic=form_newTopic, city=city, id=to_id)


@app.route('/question/<topic_id>', methods=['GET', 'POST'])
@login_required
def question(topic_id):
    form_newQuestion = AddQuestionForm()
    form_newTopic = AddTopicForm()
    if form_newTopic.validate_on_submit():
        username = current_user.username
        topic_name = request.form['title']
        city= request.form['city']
        new_topic = dbquery.newTopic(username, city, topic_name)
        topic_id=new_topic.id
        t_question = request.form['topic_question']
        new_question = dbquery.newQuestion(username, t_question, topic_id)
        db.session.add(new_topic)
        db.session.commit()
        db.session.add(new_question)
        db.session.commit()

    questions = dbquery.get_question_from_topic(topic_id)
    return render_template('question.html', questions=questions, form=form_newQuestion, topic_id=topic_id)


@app.route('/question', methods=['GET', 'POST'])
@login_required
def newquestion():
    form_newQuestion = AddQuestionForm()
    username = current_user.username
    topic_id=request.form['topic_id']
    question_ = request.form['question']
    city= request.form['city']
    new_question = dbquery.newQuestion(username, question_, topic_id)
    db.session.add(new_question)
    db.session.commit()
    questions = dbquery.get_question_from_topic(topic_id)
    return render_template('question.html', questions=questions, topic_id=topic_id, form=form_newQuestion, city=city)


@app.route('/forum', methods=['GET', 'POST'])
@login_required
def forum():
    form = ForumForm()
    if form.validate_on_submit():
        city = request.form['cities']
        return redirect(url_for('topic', city=city))

    return render_template('forum.html', form=form)


@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    form1 = MaterialForm()
    form2 = UploadForm()

    file = request.files['doc']


    title = request.form['title']
    author = current_user.username
    university = request.form['university']
    professor = request.form['professor']
    subject = request.form['subject']
    description = request.form['description']

    num = dbquery.countMaterial()

    newrow = Material(
        id=num,
        title=title,
        link=file,
        author=author,
        university=university,
        professor=professor,
        subject=subject,
        description=description,
        rating=''
    )

    db.session.add(newrow)
    db.session.commit()

    filename = secure_filename(file.filename)
    file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
    return redirect(url_for('uploaded_file',
                            filename=filename))


@app.route('/upload/<filename>')
@login_required
def uploaded_file(filename):
    send_from_directory(app.config['UPLOAD_FOLDER'],
                               filename)
    return render_template('upload.html')


@app.route('/download', methods=['GET', 'POST'])
@login_required
def download():
    form = DownloadForm()
    link = request.form['link']
    url = link.join([c for c in link if c.isalpha() or c.isdigit() or c == ' ']).rstrip()
    list = url.split('\'')
    link = list[1]
    string = link
    filename = string.replace(" ", "_")

    return redirect(url_for('download_file',
                                filename=filename))


@app.route('/download/<filename>')
@login_required
def download_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'],
                               filename)


@app.route('/rating', methods=['GET', 'POST'])
@login_required
def rating():
    form = RatingForm()

    idmaterial = request.form['material']
    intmaterial = int(idmaterial)
    new_rate = dbquery.get_rating_by_id(intmaterial) + 1
    db.session.query(Material).filter(Material.id == intmaterial).update(
        {'rating': new_rate})  # method to update column database
    db.session.commit()
    return render_template('rating.html')


@app.route('/delete', methods=['GET', 'POST'])
@login_required
def delete():
    form = DeleteForm()

    idmat = request.form['material']
    intidmat = int(idmat)
    db.session.query(Material).filter(Material.id == intidmat).delete()
    db.session.commit()

    return render_template('delete.html')


@app.route('/contact', methods=['GET', 'POST'])
def contact():
  form = ContactForm()

  if request.method == 'POST':
    if form.validate() == False:
      flash('All fields are required.')
      return render_template('contact.html', form=form)
    else:
      msg = Message(form.subject.data, sender='contact@example.com', recipients=['erasmuslife.contact@gmail.com'])
      msg.body = """
      From: %s &lt;%s&gt;
      %s
      """ % (form.name.data, form.email.data, form.message.data)
      mail.send(msg)

      return render_template('contact.html', success=True)

  elif request.method == 'GET':
    return render_template('contact.html', form=form)



if __name__ == '__main__':
    app.run(debug=True)
