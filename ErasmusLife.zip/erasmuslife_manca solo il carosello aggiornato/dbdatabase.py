from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Text, BLOB, Enum,  Table
from sqlalchemy.orm import relationship, backref
from flask.ext.sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask.ext.login import UserMixin

db = SQLAlchemy()
Base = db.Model

class User(Base):
    __tablename__ = 'user'
    username = Column(String(20), primary_key=True)
    types = Column(Enum('T', 'S'), nullable=False)
    password_hash = Column(String(512), nullable=False)
    email = Column(String(50), nullable=False)

    def __init__(self, username, types, password, email):
        self.username = username
        self.types = types
        self.password = password
        self.email = email

    @property
    def is_authenticated(self):
        return True

    @property
    def is_active(self):
        return True

    @property
    def is_anonymous(self):
        return False

    @property
    def password(self):
        raise AttributeError('password is write-only')

    @password.setter
    def password(self, password):
        self.password_hash = generate_password_hash(password)

    def verify_password(self, password):
        return check_password_hash(self.password_hash, password)

    def get_id(self):
        return self.username

class Tutor(Base):
    __tablename__ = 'tutor'
    username = Column(String(20), ForeignKey('user.username'), primary_key=True)
    name = Column(String(30), nullable=False)
    surname = Column(String(30), nullable=False)
    date_of_birth = Column(DateTime, nullable=False)
    description = Column(Text)
    city = Column(String(30))
    university = Column(String(50), nullable=False)
    photo = Column(BLOB)

    user=relationship('User', uselist=False, backref='tutor')

    def __init__(self, username, name, surname, date_of_birth, description, city, university,
                 photo):

        self.username = username
        self.name = name
        self.surname = surname
        self.date_of_birth = date_of_birth
        self.description = description
        self.city = city
        self.university = university
        self.photo = photo

class University(Base):
    __tablename__ = 'university'

    name = Column(String(50), primary_key=True)
    city = Column(String(30), nullable=False)

    def __init__(self, name, city):
        self.name = name
        self.city = city

    def get_city(self):
        return self.city

    def get_name(self):
        return self.name

class Topic(Base):
    __tablename__ = 'topic'
    id = Column(Integer, primary_key=True)
    topic = Column(String(50), nullable=False)
    username = Column(String(20), ForeignKey('user.username'), nullable=False)
    date = Column(DateTime)
    city = Column(String(30), nullable=False)

    user=relationship('User', backref='topics')

    def __init__(self, id, topic, username, date, city):
        self.id = id
        self.topic = topic
        self.username = username
        self.date = date
        self.city = city

    def get_topic(self):
        return self.topic

    def get_id(self):
        return self.id

class Question(Base):
    __tablename__ = 'question'
    id = Column(Integer, primary_key=True)
    id_topic = Column(Integer, ForeignKey('topic.id'), nullable=False)
    username = Column(String(20), ForeignKey('user.username'), nullable=False)
    question = Column(String(100), nullable=False)
    date = Column(DateTime, nullable=False)

    quest=relationship('Topic', backref='questions')
    user_quest=relationship('User', backref='questions')

    def __init__(self, id, id_topic, username, question, date):
        self.id = id
        self.id_topic = id_topic
        self.username = username
        self.question = question
        self.date = date


class Material(Base):
    __tablename__ = 'material'
    id = Column(Integer, primary_key=True)
    title = Column(String(100), nullable=False)
    link = Column(String(200), nullable=False)
    author = Column(String(20), ForeignKey('tutor.username'), nullable=False)
    university = Column(Integer, ForeignKey('university.name'), nullable=False)
    professor = Column(String(30), nullable=False)
    subject = Column(String(30), nullable=False)
    description = Column(Text, nullable=False)
    rating = Column(Integer)

    a_author = relationship('Tutor', backref='materials')
    uni=relationship('University', backref='materials')
    def __init__(self, id, title, link, author, university, professor, subject, description, rating):
        self.id = id
        self.title = title
        self.link = link
        self.author = author
        self.university = university
        self.professor = professor
        self.subject = subject
        self.description = description
        self.rating = rating

    def get_id(self):
        return self.id

    def get_title(self):
        return self.title

    def get_link(self):
        return self.link

    def get_author(self):
        return self.author

    def get_university(self):
        return self.university

    def get_professor(self):
        return self.professor

    def get_subject(self):
        return self.subject

    def get_description(self):
        return self.description

    def get_rating(self):
        return self.rating